export const ASSETS = {
  appIcon: "/assets/app-icon.png",
  badges: {
    frame: "/assets/ui/badge-frame.png",
    rocketBoost: "/assets/badges/rocket-boost.png",
    shieldVerified: "/assets/badges/shield-verified.png",
    shieldLock: "/assets/badges/shield-lock.png",
    shieldEnergy: "/assets/badges/shield-energy.png",
    crownUpgrade: "/assets/badges/crown-upgrade.png",
    flameCore: "/assets/badges/flame-core.png",
  },
  avatars: {
    mysteryGentleman: "/assets/avatars/mystery-gentleman.png",
  },
  story: {
    teaser: "/assets/story/story-teaser.png",
  },
  og: {
    main: "/assets/og/og-main.png",
  },
} as const;

export type AssetPath = string;

export function asset(path?: string | null, fallback: string = ASSETS.appIcon): string {
  if (!path || typeof path !== "string") return fallback;
  return path.startsWith("/") ? path : `/${path}`;
}

export default ASSETS;

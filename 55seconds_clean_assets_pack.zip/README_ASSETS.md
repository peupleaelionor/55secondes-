# 55 Seconds — clean asset pack

Pack généré pour compléter les assets manquants du build.

## Chemins inclus

- `public/assets/app-icon.png`
- `public/assets/ui/badge-frame.png`
- `public/assets/badges/rocket-boost.png`
- `public/assets/badges/shield-verified.png`
- `public/assets/badges/shield-lock.png`
- `public/assets/badges/shield-energy.png`
- `public/assets/badges/crown-upgrade.png`
- `public/assets/badges/flame-core.png`
- `public/assets/avatars/mystery-gentleman.png`
- `public/assets/story/story-teaser.png`
- `public/assets/og/og-main.png`
- `lib/assets.ts`

## Intégration recommandée

1. Dézipper à la racine du repo.
2. Remplacer/merger `lib/assets.ts` si un mapping existe déjà.
3. Vérifier que toutes les références UI passent par `ASSETS`.
4. Garder les fallbacks : aucun asset manquant ne doit casser le build.
5. Lancer :
   ```bash
   pnpm lint
   pnpm build
   ```

## Note

Ces fichiers sont des remplacements propres, sans filigrane ni mention d’outil externe.
